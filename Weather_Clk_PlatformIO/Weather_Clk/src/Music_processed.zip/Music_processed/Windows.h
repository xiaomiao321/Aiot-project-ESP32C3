const int melody_windows[] PROGMEM= {
  1244,   311,   415,   932,   415,   311,   1244,   622,   1864, 
};

const int durations_windows[] PROGMEM = {
  154,   187,   1,   126,   437,   289,   187,   117,   600, 
};

// Song length: 9 notes
// Generated from Windows.mid
